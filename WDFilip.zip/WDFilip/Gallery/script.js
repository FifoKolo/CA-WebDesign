var imgFlipped = 0;
function flip(){

		
		if(imgFlipped==0){;
			document.getElementById("image1").src = "Images/badairtext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image1").src = "Images/badair1.jpg";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
function flip1(){

		
		if(imgFlipped==0){;
			document.getElementById("image2").src = "Images/goodairtext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image2").src = "Images/goodair1.png";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
function flip2(){

		
		if(imgFlipped==0){;
			document.getElementById("image3").src = "Images/badlandtext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image3").src = "Images/badland1.png";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
function flip3(){

		
		if(imgFlipped==0){;
			document.getElementById("image4").src = "Images/goodlandtext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image4").src = "Images/goodland1.jpg";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
function flip4(){

		
		if(imgFlipped==0){;
			document.getElementById("image5").src = "Images/badseatext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image5").src = "Images/badsea1.jpg";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
function flip5(){

		
		if(imgFlipped==0){;
			document.getElementById("image6").src = "Images/goodseatext.png";/*this changes the image when the image gets clicked on, the image changes to the text*/
			imgFlipped=1;
		}else if(imgFlipped==1){;
		document.getElementById("image6").src = "Images/goodsea1.jpg";/* this is the default image that popus up automatically when you open the page*/
		imgFlipped=0;
		}
}
